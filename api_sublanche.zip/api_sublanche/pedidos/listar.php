<?php
    require_once('../conexao.php');
    $postjson = json_decode(file_get_contents('php://input'), true);

    $queryProdutos = $pdo->query("SELECT * FROM produtos");
	$resProdutos = $queryProdutos->fetchAll(PDO::FETCH_ASSOC);
	$totalProdutos = @count($resProdutos);
	if($totalProdutos > 0){ 

        for($i=0; $i < $totalProdutos; $i++){
            foreach ($resProdutos[$i] as $key => $value){	}

            $produtos[] = array(
                'id_prod' => $resProdutos[$i]['id_prod'],
                'nome' => $resProdutos[$i]['nome'],
                'descricao' => $resProdutos[$i]['descricao'],
                'categoria' => $resProdutos[$i]['categoria'],
                'preco' => $resProdutos[$i]['preco'],
            );  
        }

    }else{
        $produtos[] = array(); 
    }

    $queryMesas = $pdo->query("SELECT * FROM mesas");
	$resMesas = $queryMesas->fetchAll(PDO::FETCH_ASSOC);
	$totalMesas = @count($resMesas);
	if($totalMesas > 0){ 

        for($i=0; $i < $totalMesas; $i++){
            foreach ($resMesas[$i] as $key => $value){	}

            $mesas[] = array(
                'id' => $resMesas[$i]['id'],
                'numero' => $resMesas[$i]['numero'],
            );
            
        }

    }else{
        $mesas[] = array(); 
    }

    $result = json_encode(array('produtos'=>$produtos, 'mesas'=>$mesas));
    echo $result;
?>