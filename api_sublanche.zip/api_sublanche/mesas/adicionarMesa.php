<?php

require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'), true);

$numero = $postjson['numero'];

if ($numero == "") {
    echo json_encode(array("msg" => "Informe o numero da mesa!"));
    exit;
}

$sql = "SELECT * FROM mesas WHERE numero = :numero";
$con = $pdo->prepare($sql);
$con->bindValue(":numero", $numero);
$con->execute();
$dados = $con->fetchAll(PDO::FETCH_ASSOC);

if (@count($dados) > 0) {
    echo json_encode(array("msg" => "A mesa já está cadastrado!"));
    exit;
}

// Iniciar uma transação para garantir que ambas as inserções tenham sucesso ou falhem juntas
$pdo->beginTransaction();

try {
    // Parte 1: Inserir o produto
    $sql = "INSERT INTO mesas (numero) VALUES (:numero)";
    $con = $pdo->prepare($sql);
    $msg = "Salvo com sucesso";
    $con->bindValue(":numero", $numero);
    $con->execute();

    // Parte 2: Obter o último produto_id inserido
    $id = $pdo->lastInsertId();

    // Commit da transação
    $pdo->commit();

    echo json_encode(
        array(
            'ok' => true,
            'msg' => $msg,
            'numero' => $numero,
            'id' => $id,
        )
    );
} catch (PDOException $e) {
    // Em caso de falha, desfazer a transação
    $pdo->rollBack();
    echo json_encode(array("msg" => "Não foi possível cadastrar a mesa. Erro: " . $e->getMessage()));
    exit;
}
?>