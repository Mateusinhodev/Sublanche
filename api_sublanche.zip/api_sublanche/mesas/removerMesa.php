<?php

require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'), true);

$idMesa = @$postjson['id_mesa'];

if (!$idMesa) {
    echo json_encode(array("msg" => "ID da mesa não informado"));
    exit;
}

// Verificar se a mesa existe antes de tentar remover
$sql = "SELECT * FROM mesas WHERE id = :idMesa";
$con = $pdo->prepare($sql);
$con->bindValue(":idMesa", $idMesa);
$con->execute();
$dados = $con->fetchAll(PDO::FETCH_ASSOC);

if (@count($dados) == 0) {
    echo json_encode(array("msg" => "A mesa não existe"));
    exit;
}

// Remover a mesa do banco de dados
$sql = "DELETE FROM mesas WHERE id = :idMesa";
$con = $pdo->prepare($sql);
$con->bindValue(":idMesa", $idMesa);

if (@$con->execute()) {
    echo json_encode(array("msg" => "Mesa removida com sucesso", "ok" => true));
    exit;
} else {
    echo json_encode(array("msg" => "Não foi possível remover a mesa"));
    exit;
}
?>