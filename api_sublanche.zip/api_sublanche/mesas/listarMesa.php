<?php
    require_once('../conexao.php');
    $postjson = json_decode(file_get_contents('php://input'), true);

    // $img = [
    //     'id'=> [],
    //     'link'=> []
    // ];

    // $query_img = $pdo->query("SELECT * FROM produtos");
	// $resImg = $query_img->fetchAll(PDO::FETCH_ASSOC);
	// $total_img = @count($resImg);
	// if($total_img > 0){
    //     for($i=0; $i < $total_img; $i++){
    //         array_push($img['id'], $resImg[$i]['imagens_produtos_id']);
    //         array_push($img['link'], $resImg[$i]['imagens_link']);
    //     }
    // }

    $query = $pdo->query("SELECT * FROM mesas");
	$res = $query->fetchAll(PDO::FETCH_ASSOC);
	$total_reg = @count($res);
	if($total_reg > 0){ 

        for($i=0; $i < $total_reg; $i++){
            foreach ($res[$i] as $key => $value){	}

            $dados[] = array(
                'id' => $res[$i]['id'],
                'numero' => $res[$i]['numero'],
            );
            
        }

        $result = json_encode(array('itens'=>$dados));
        echo $result;

    }else{
        $result = json_encode(array('itens'=>'0'));
        echo $result; 
    }

?>