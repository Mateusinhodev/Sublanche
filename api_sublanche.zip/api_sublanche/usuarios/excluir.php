<?php
require_once('../conexao.php');
$postjson = json_decode(file_get_contents('php://input'), true);

$id_fun = @$postjson['id_fun'];

$res = $pdo->query("DELETE FROM usuarios where id_fun = '$id_fun'");

$result = json_encode(array('mensagem' => 'Excluído com Sucesso', 'ok' => true));
echo $result;
