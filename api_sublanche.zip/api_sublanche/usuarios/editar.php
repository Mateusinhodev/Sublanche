<?php

require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'),true);

$id_fun = $postjson['id_fun'];
$nome = $postjson['nome'];
$senha = $postjson['senha'];
$funcao = $postjson['funcao'];

$nome_antigo = $postjson['nome_antigo'];

if($nome == ""){
    echo json_encode(array("msg"=>"Informe o nome do usuário!"));
    exit;
}

if($senha == ""){
    echo json_encode(array("msg"=>"Informe uma senha!"));
    exit;
}

if($funcao == ""){
    echo json_encode(array("msg"=>"Informe a funcao de acesso!"));
    exit;
}

if($nome_antigo != $nome){
    $sql = "SELECT * FROM usuarios WHERE nome = :nome AND id_fun = :id_fun";
    $con = $pdo->prepare($sql);
    $con->bindValue(":nome", $nome);
    $con->bindValue(":id_fun", $id_fun);
    $con->execute();
    $dados = $con->fetchAll(PDO::FETCH_ASSOC);
    if(@count($dados) > 0){
        echo json_encode(array("msg"=>"O nome já está cadastrado!"));
        exit;
    }

}


$sql = "UPDATE usuarios SET nome = :nome, senha = :senha, funcao = :funcao WHERE id_fun = :id_fun";
$con = $pdo->prepare($sql);
$con->bindValue(":id_fun", $id_fun);
$con->bindValue(":nome", $nome);
$con->bindValue(":senha", $senha);
$con->bindValue(":funcao", $funcao);
$msg = "Alterado com sucesso";
if(@$con->execute()){
    //echo json_encode(array("msg"=>"Cadastrado com sucesso!"));
    echo json_encode(
        array(
            'ok' => true,
            'msg'=> $msg,
            'nome'=> $nome, 
            'senha' => $senha,
            'funcao' => $funcao
        ));
        
    exit;
}else{
    echo json_encode(array("msg"=>"Não foi Alterado!"));
    exit;
}
//echo $result;


?>