<?php
require_once('../conexao.php');
$postjson = json_decode(file_get_contents('php://input'), true);

$id_prod = @$postjson['id_prod'];

$res = $pdo->query("DELETE FROM produtos where id_prod = '$id_prod'");

$result = json_encode(array('mensagem' => 'Excluído com Sucesso', 'ok' => true));
echo $result;
