<?php
    require_once('../conexao.php');
    $postjson = json_decode(file_get_contents('php://input'), true);

    $limite = intVal($postjson['limit']);
    $start = intVal($postjson['start']);
    $categoria = $postjson['categoria'];

    $img = [
        'id'=> [],
        'link'=> []
    ];

    // $query_img = $pdo->query("SELECT * FROM produtos");
	// $resImg = $query_img->fetchAll(PDO::FETCH_ASSOC);
	// $total_img = @count($resImg);
	// if($total_img > 0){
    //     for($i=0; $i < $total_img; $i++){
    //         array_push($img['id'], $resImg[$i]['imagens_produtos_id']);
    //         array_push($img['link'], $resImg[$i]['imagens_link']);
    //     }
    // }

    $busca = '%'.$postjson['nome'].'%';
    $query = $pdo->query("SELECT * FROM produtos where nome LIKE '$busca' and categoria = '$categoria' order by nome desc limit $start, $limite");
	$res = $query->fetchAll(PDO::FETCH_ASSOC);
	$total_reg = @count($res);
	if($total_reg > 0){ 

        for($i=0; $i < $total_reg; $i++){
            foreach ($res[$i] as $key => $value){	}

            $dados[] = array(
                'id_prod' => $res[$i]['id_prod'],
                'nome' => $res[$i]['nome'],
                'descricao' => $res[$i]['descricao'],
                'preco' => $res[$i]['preco'],
                'categoria' => $res[$i]['categoria'],
                'imagem_path' => $res[$i]['imagem_path'],
            );
            
        }

        $result = json_encode(array('itens'=>$dados));
        echo $result;

    }else{
        $result = json_encode(array('itens'=>'0'));
        echo $result; 
    }

?>