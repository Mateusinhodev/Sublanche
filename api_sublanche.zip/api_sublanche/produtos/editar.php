<?php

require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'),true);

$nome = $postjson['nome'];
$descricao = $postjson['descricao'];
$preco = $postjson['preco'];
$categoria = $postjson['categoria'];

$nome_antigo = $postjson['nome_antigo'];
$id_prod = $postjson['id_prod'];

$msg = "Não foi Alterado";

if($nome == ""){
    echo json_encode(array("msg"=>"Informe o nome do produto!"));
    exit;
}

if($descricao == ""){
    echo json_encode(array("msg"=>"Insira a descricao!"));
    exit;
}

if($preco == ""){
    echo json_encode(array("msg"=>"Informe o preco!"));
    exit;
}

if($categoria == ""){
    echo json_encode(array("msg"=>"Informe a categoria do produto!"));
    exit;
}

if($nome_antigo != $nome){
    $sql = "SELECT * FROM produtos WHERE nome = :nome AND id_prod = :id_prod";
    $con = $pdo->prepare($sql);
    $con->bindValue(":nome", $nome);
    $con->bindValue(":id_prod", $id_prod);
    $con->execute();
    $dados = $con->fetchAll(PDO::FETCH_ASSOC);
    // if(@count($dados) > 0){
    //     echo json_encode(array("msg"=>"O nome do produto já foi inserido!"));
    //     exit;
    // }

}

$sql = "UPDATE produtos SET nome = :nome, descricao = :descricao, preco = :preco, categoria = :categoria WHERE id_prod = :id_prod";
$con = $pdo->prepare($sql);
$con->bindValue(":id_prod", $id_prod);
$con->bindValue(":nome", $nome);
$con->bindValue(":descricao", $descricao);
$con->bindValue(":preco", $preco);
$con->bindValue(":categoria", $categoria);
$msg = "Alterado com sucesso";
if(@$con->execute()){
    //echo json_encode(array("msg"=>"Cadastrado com sucesso!"));
    echo json_encode(
        array(
            'ok' => true,
            'msg'=> $msg,
            'nome'=> $nome, 
            'descricao'=> $descricao,
            'preco'=> $preco,
            'categoria' => $categoria
        ));
        
    exit;
}else{
    echo json_encode(array("msg"=>"Não foi Alterado!"));
    exit;
}
//echo $result;


?>