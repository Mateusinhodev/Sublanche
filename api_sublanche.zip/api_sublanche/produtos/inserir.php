<?php

require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'), true);

$nome = $postjson['nome'];
$descricao = $postjson['descricao'];
$preco = $postjson['preco'];
$categoria = $postjson['categoria'];


if ($nome == "") {
    echo json_encode(array("msg" => "Informe o nome do produto!"));
    exit;
}

if ($preco == "") {
    echo json_encode(array("msg" => "Informe o preco!"));
    exit;
}

if ($descricao == "") {
    echo json_encode(array("msg" => "Informe a descricao!"));
    exit;
}

if ($categoria == "") {
    echo json_encode(array("msg" => "Informe a categoria"));
    exit;
}

$sql = "SELECT * FROM produtos WHERE nome = :nome";
$con = $pdo->prepare($sql);
$con->bindValue(":nome", $nome);
$con->execute();
$dados = $con->fetchAll(PDO::FETCH_ASSOC);

if (@count($dados) > 0) {
    echo json_encode(array("msg" => "O nome já está cadastrado!"));
    exit;
}

// Iniciar uma transação para garantir que ambas as inserções tenham sucesso ou falhem juntas
$pdo->beginTransaction();

try {
    // Parte 1: Inserir o produto
    $sql = "INSERT INTO produtos (nome, preco, descricao, categoria) VALUES (:nome, :preco, :descricao, :categoria)";
    $con = $pdo->prepare($sql);
    $msg = "Salvo com sucesso";
    $con->bindValue(":nome", $nome);
    $con->bindValue(":preco", $preco);
    $con->bindValue(":descricao", $descricao);
    $con->bindValue(":categoria", $categoria);
    $con->execute();

    // Parte 2: Obter o último produto_id inserido
    $id_prod = $pdo->lastInsertId();

    // Parte 3: Inserir o caminho da imagem
    $imagem_path = $postjson['imagem_path'];
    $sql = "UPDATE produtos SET imagem_path = :imagem_path WHERE id_prod = :id_prod";
    $con = $pdo->prepare($sql);
    $con->bindValue(":id_prod", $id_prod);
    $con->bindValue(":imagem_path", $imagem_path);
    $con->execute();

    // Commit da transação
    $pdo->commit();

    echo json_encode(
        array(
            'ok' => true,
            'msg' => $msg,
            'nome' => $nome,
            'preco' => $preco,
            'descricao' => $descricao,
            'categoria' => $categoria,
            'id_prod' => $id_prod,
            'imagem_path' => $imagem_path,
        )
    );
} catch (PDOException $e) {
    // Em caso de falha, desfazer a transação
    $pdo->rollBack();
    echo json_encode(array("msg" => "Não foi possível cadastrar o produto. Erro: " . $e->getMessage()));
    exit;
}
?>