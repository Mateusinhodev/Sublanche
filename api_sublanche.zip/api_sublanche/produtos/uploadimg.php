<?php

require_once('../conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['imagem']) && $_FILES['imagem']['error'] == UPLOAD_ERR_OK) {
    $uploads_dir = 'uploads/';

    $tmp_name = $_FILES['imagem']['tmp_name'];
    $name = $_FILES['imagem']['name'];

    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
    $file_extension = pathinfo($name, PATHINFO_EXTENSION);

    if (!in_array(strtolower($file_extension), $allowed_extensions)) {
        echo json_encode(['msg' => 'Extensão de arquivo não permitida']);
        exit;
    }

    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0777, true);
    }

    $imagem_path = $uploads_dir . $name;

    if (move_uploaded_file($tmp_name, $imagem_path)) {
        // Obter apenas o nome do arquivo sem o caminho
        $nome_do_arquivo = basename($imagem_path);
        echo json_encode(['imagem_path' => $nome_do_arquivo, 'msg' => 'Upload de imagem bem-sucedido']);
    } else {
        echo json_encode(['msg' => 'Falha no upload de imagem']);
    }
} else {
    echo json_encode(['msg' => 'Erro no upload de imagem']);
}

?>
