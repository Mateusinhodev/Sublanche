<?php
require_once('../conexao.php');

$postjson = json_decode(file_get_contents('php://input'), true);

$id_fun = $postjson['id_fun'];
$senha = $postjson['senha'];

$sql = "SELECT * FROM usuarios WHERE id_fun = :id_fun AND senha = :senha";
$con = $pdo->prepare($sql);
$con->bindValue(":id_fun", $id_fun);
$con->bindValue(":senha", $senha);
$con->execute();
$dados = $con->fetch(PDO::FETCH_ASSOC);

if ($dados) {
    echo json_encode([
        'ok' => true,
        'msg' => 'Login bem-sucedido',
        'id_fun' => $dados['id_fun'],
        'nome' => $dados['nome'],
        'funcao' => $dados['funcao'],
    ]);
} else {
    echo json_encode(['ok' => false, 'msg' => 'CPF ou senha incorretos']);
}

exit;
?>



