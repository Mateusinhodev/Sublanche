import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
//import 'rxjs/add/operator/map';
import {Observable, map} from  'rxjs';


@Injectable()
export class Api{
    // server: string = 'http://localhost/api/';
    server: string = 'http://localhost/api_sublanche/';
    private apiUrl = 'http://localhost/api_sublanche/login/'; 
    
    constructor(private http : HttpClient){}


    dadosApi(dados: any, api: string){
            const httpOptions = {
                headers: new HttpHeaders({'Content-Type' : 'application/json'})
                }

            let url = this.server + api;
            return this.http.post(url, JSON.stringify(dados), httpOptions).pipe(map(res => res));
        }

    login(id_fun: string, senha: string): Observable<any> {
        const data = { id_fun, senha };
        return this.http.post(`${this.apiUrl}/login.php`, data);
    }
    
    uploadImagem(formData: FormData) {
        return this.http.post('http://localhost/api_sublanche/produtos/uploadimg.php', formData, {
          reportProgress: true,
          observe: 'response',
        });
      }

    adicionarMesa(numeroMesa: number): Observable<any> {
        const data = { numero_mesa: numeroMesa };
        return this.http.post(`${this.server}mesas/adicionarMesa.php`, data);
      }
    
      removerMesa(idMesa: number): Observable<any> {
        const data = { id_mesa: idMesa };
        return this.http.post(`${this.server}mesas/removerMesa.php`, data);
      }
        
}
