import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController, ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-add-usuario',
  templateUrl: './add-usuario.page.html',
  styleUrls: ['./add-usuario.page.scss'],
})
export class AddUsuarioPage implements OnInit {

  dados: any;

  nome: string = '';
  senha: string = '';
  funcao: string = '';
  id_fun: string = '';
  imagem_path:string = "" // Variável para receber a imagem
  selectedImage: File = null as any;

  nome_antigo: string = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private provider: Api,
    private api: Api,
    public toast: ToastController,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    this.msg("Carregando os dados...", "primary");
    this.activatedRoute.params.subscribe((dados)=> {
      this.dados = dados;

      this.nome = this.dados.nome;
      this.senha = this.dados.senha;
      this.funcao = this.dados.funcao;
      this.id_fun = this.dados.id_fun;

      this.nome_antigo = this.dados.nome;
    });
  }

  async msg(msg:string, cor:string){
    const toast = await this.toast.create({
      message: msg,
      duration: 2000,
      color: cor
    });
    toast.present();
  }

  clearFields(){
    this.nome  = '';
    this.senha   = '';
    this.funcao = '';
};

salvar() {
  if (!this.nome || !this.senha || !this.funcao) {
    this.msg("Por favor, preencha todos os campos obrigatórios.", "danger");
    return;
  }

  const formData = new FormData();
  formData.append('imagem', this.selectedImage);

  this.provider.uploadImagem(formData).subscribe(
    (response: any) => {
      if (response.body && response.body.imagem_path) {
        // Imagem carregada com sucesso, agora salvar os dados do produto
        this.imagem_path = response.body.imagem_path;

        let dados = {
          nome: this.nome,
          senha: this.senha,
          funcao: this.funcao,
          id_fun: this.id_fun,
          imagem_path: this.imagem_path, // Usando o caminho da imagem
        };

        this.provider.dadosApi(dados, 'usuarios/inserir.php').subscribe(
          (itens: any) => {
            if (itens.ok == true) {
              this.router.navigate(['/usuario']);
              this.msg(itens.msg, "success");
              this.clearFields();
            } else {
              this.msg(itens.msg, "danger");
            }
          },
          (error) => {
            console.error('Erro ao salvar dados do produto', error);
            this.msg('Erro ao salvar dados do produto', 'danger');
          }
        );
      } else {
        console.error('Erro no upload de imagem', response.body ? response.body.msg : 'Resposta inválida');
        this.msg('Erro no upload de imagem', 'danger');
      }
    },
    (error) => {
      console.error('Erro no upload de imagem', error);
      this.msg('Erro no upload de imagem', 'danger');
    }
  );
}

onFileSelected(event: any) {
  const fileInput = event.target;

  if (fileInput.files.length > 0) {
    this.selectedImage = fileInput.files[0];

    // Criar uma URL temporária para a imagem
    const reader = new FileReader();
    
    reader.readAsDataURL(this.selectedImage);
  } else {
    this.selectedImage = null as any;
  
}
}

editar(){
  return new Promise(resolve =>{
    let dados = {
      nome: this.nome,
      senha: this.senha,
      funcao: this.funcao,
      nome_antigo: this.nome_antigo,
      id_fun: this.id_fun
    };
    console.log("Dados", dados);

    let itens:any;
    this.provider.dadosApi(dados, 'usuarios/editar.php').subscribe(
      data => {
        itens = data;
        console.log("itens.ok",itens.ok);
        if(itens.ok == true){
          
          this.router.navigate(['usuario']);
          this.msg(itens.msg, "success");
          this.clearFields();
        }else{
          this.msg(itens.msg, "danger");
        }
        console.log("Dados", itens.msg, itens.nome, itens.senha, itens.funcao);
      }
    )
  });

}

// //metodo editar
// async editar(){
//   return new Promise(resolve =>{
//     //declaracao das variaveis
//     let dados = {
//       nome: this.nome,
//       senha: this.senha,
//       funcao: this.funcao,
//       nome_antingo: this.nome_antigo,
//       id_fun: this.id_fun,
//     };
//     let itens:any;

//     // comunicação com a API
//     this.provider.dadosApi(dados,'usuarios/editar.php').subscribe(
//       data => {
//         itens = data;
//         console.log('Itens:',itens);
//         if(itens.ok == true){
//           this.router.navigate(['usuarios']);
//           this.msg(itens.msg, "success");
//           this.clearFields();
//         }else{
//           this.msg(itens.msg, "danger");
//         }
//       }
//     )
//   });

// }

  voltar() {
    this.router.navigate(['tabs/painel']);
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }

  navegarUsuario() {
    this.router.navigate(['usuario']);
  }
}
