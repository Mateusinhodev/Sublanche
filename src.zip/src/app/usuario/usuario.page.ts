import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.page.html',
  styleUrls: ['./usuario.page.scss'],
})
export class UsuarioPage implements OnInit {

  // Declaração das variaveis
  itens: any = [];
  limit: number = 10;
  start: number = 0;
  nome: string = "";

  constructor(
    private router: Router,
    private provider: Api,
    private actRouter: ActivatedRoute,
    public toastController: ToastController
  ) { }

  ngOnInit() {
  }

  // navegação atá a página add-usuarios
  addUsuarios() {
    this.router.navigate(['add-usuario']);
  }

  //carregamento dinamico na rolagen da lista
  ionViewWillEnter() {
    this.itens = [];
    this.start = 0;
    this.carregar();
  }

  // mensagem de retorno
  async mensagem(mensagem: string, cor: string) {
    const toast = await this.toastController.create({
      message: mensagem,
      duration: 2000,
      color: cor
    });
    toast.present();
  }

  //Carregar os Dados
  carregar() {
    return new Promise(resolve => {
      this.itens = [];

      let dados = {

        nome: this.nome,
        limit: this.limit,
        start: this.start
      }

      this.provider.dadosApi(dados, 'usuarios/listar.php').subscribe(data => {
        let result: any = data;
        console.log("Resultado", result.itens, result.itens.length);
        if (result.itens.length == '0') {
          this.ionViewWillEnter();
        } else {
          this.itens = [];
          for (let item of result.itens) {
            this.itens.push(item);

          }
        }

        resolve(true);

      });
    });

  }

  // metodo editar
  editar(id_fun: Number, nome: string, senha: string, funcao: string) {
    this.router.navigate(['add-usuario', { id_fun: id_fun, nome: nome, senha: senha, funcao: funcao }]);
  }

  //metodo excluir
  excluir(id_fun: Number) {
    return new Promise(resolve => {
      let dados = {
        id_fun: id_fun,

      }
      let result: any;
      this.provider.dadosApi(dados, 'usuarios/excluir.php').subscribe(
        data => {
          result = data;
          if (result.ok == true) {
            this.carregar();
            this.mensagem(result.mensagem, 'success');

          } else {
            this.mensagem(result.mensagem, 'danger');
          }
        }
      )
    });
  }

  // metodo mostrar as informações
  mostrar(id_fun: Number, nome: string, senha: string, funcao: string) {
    this.router.navigate(['perfil', { id_fun: id_fun, nome: nome, senha: senha, funcao: funcao }]);
  }

  //atualizar visualização dos itens da lista
  handleRefresh(event: any) {
    setTimeout(() => {
      this.ionViewWillEnter();
      event.target.complete();
    }, 500);
  }

  //Carregar os dados por meio do scrool
  loadData(event: any) {

    this.start += this.limit;

    setTimeout(() => {
      this.carregar().then(() => {
        event.target.complete();
      });

    }, 500);


  }

  voltar() {
    this.router.navigate(['tabs/painel']);
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }
}
