import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  id_fun: string = "";
  senha: string = "";

  constructor(
    private router:Router, 
    private Api:Api,
    public toastController: ToastController,
  ) { }

  ngOnInit() {
  }

  // // mensagem de retorno
  // async mensagem(mensagem: string, cor: string) {
  //   const toast = await this.toastController.create({
  //     message: mensagem,
  //     duration: 2000,
  //     color: cor,
  //   });
  //   toast.present();
  // }

  fazerLogin() {
    if (!this.id_fun && !this.senha) {
      this.mostrarMensagem('Por favor, preencha o Id e senha!', 'danger');
      return; // Impede a execução do código seguinte se o CPF ou a senha estiverem vazios
    }
    if (!this.id_fun) {
      this.mostrarMensagem('Por favor, informe o Id!', 'warning');
      return; // Impede a execução do código seguinte se o CPF ou a senha estiverem vazios
    }
    if (!this.senha) {
      this.mostrarMensagem('Por favor, informe a Senha!', 'warning');
      return; // Impede a execução do código seguinte se o CPF ou a senha estiverem vazios
    }

    this.Api.login(this.id_fun, this.senha).subscribe(
      (data) => {

        if (data.ok) {

          if (data.funcao === 'Administrador') {

            this.router.navigate(['tabs/home']);
            this.mostrarMensagem('Administrador, seja Bem-vindo!', 'success');

            this.clearFields();
          }

          if (data.funcao === 'Conzinheiro') {

            this.router.navigate(['tabs/home']);
            this.mostrarMensagem('Conzinheiro, Seja Bem-vindo!', 'success');

            this.clearFields();
          }

          if (data.funcao === 'Garçom') {

            this.router.navigate(['tabs/home']);
            this.mostrarMensagem('Garçom, Seja Bem-vindo!', 'success');

            this.clearFields();
          }
          
        } else {
          this.mostrarMensagem('Id ou Senha Incorretos!', 'danger');
        }
      }
    );
  }

  clearFields() {
    this.id_fun = '';
    this.senha = '';
  };

  async mostrarMensagem(mensagem: string, cor: string) {
    const toast = await this.toastController.create({
      message: mensagem,
      duration: 2000,
      color: cor
    });
    toast.present();
  }

  // login(){
  //   return new Promise(resolve => {
  //     let dados = {
  //       usuario: this.usuario,
  //       senha: this.senha,   
  //     }
  //     let itens:any;
  //     this.provider.dadosApi(dados, 'login/login.php').subscribe(
  //       data=>{
  //         itens = data
          
  //         if(itens['ok'] == true){
           
  //           this.mensagem(itens['msg'], 'success');

  //           if(itens['dados']['funcao'] == 'Administrador'){
  //             console.log("Admin")
  //             console.log("Retorno de dados",itens)
  //             this.router.navigate(['Administrador']);
  //           }

  //           if(itens['dados']['funcao'] == 'Conzinheiro'){
  //             this.router.navigate(['Conzinheiro']);
  //           }

  //           if(itens['dados']['funcao'] == 'Garçom'){
  //             this.router.navigate(['Garçom']);
  //           }
                        
  //         }else{
  //           this.mensagem(itens['msg'], 'danger');
  //         }
                
          
  //       }
  //     )
  //   });
  // }
}
