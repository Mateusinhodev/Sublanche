import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-pedido',
  templateUrl: './pedido.page.html',
  styleUrls: ['./pedido.page.scss'],
})
export class PedidoPage implements OnInit {

  itens: any;
  produtos: any;
  mesas: any;

  numeroMesa: number | null = null;
  tamanhoSelecionado: any;
  observacao: any;

  constructor(
    private router: Router,
    private provider: Api,
    private actRouter: ActivatedRoute,
    public toastController: ToastController
  ) { }

  ngOnInit() {
    
  }

  //Carregar os Dados
  carregar() {
    return new Promise(resolve => {
      // carrega as variaveis
      this.itens = [];
      let dados = {
        produtos: this.produtos,
        mesas: this.mesas,
      }

      // Comunicação com a API
      this.provider.dadosApi(dados, 'pedidos/listar.php').subscribe(data => {
        let result: any = data;
        
        // carregar a lista de mesas
        if (result.mesas.length == '0') {
          this.ionViewWillEnter();
        } else {
          this.mesas = [];
          for(let item of result.mesas) {
            this.mesas.push(item);
          }
        }

        //carregar a lista de produtos;
        if (result.produtos.length == '0') {
          this.ionViewWillEnter();
        } else {
          this.produtos = [];
          for(let item of result.produtos) {
            this.produtos.push(item);
          }
        }
        resolve(true);
      });
    });
  }

  //carregamento dinamico na rolagen da lista
  ionViewWillEnter() {
    this.produtos = [];
    this.carregar();
  }

  //atualizar visualização dos itens da lista
  handleRefresh(event: any) {
    setTimeout(() => {
      this.ionViewWillEnter();
      event.target.complete();
    }, 500);
  }

  homepage() {
    this.router.navigate(['/tabs/home']);
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }

  customPopoverOptions = {
    header: 'Selecione',
  };
}
