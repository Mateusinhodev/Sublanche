import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-painel',
  templateUrl: './painel.page.html',
  styleUrls: ['./painel.page.scss'],
})
export class PainelPage implements OnInit {

  mesas: any[] = [];
  numeroMesa: number | null = null;
  mesaSelecionada: any;
  itens: any = [];
  numero: string = '';

  constructor(
    private router: Router,
    private api: Api,
    private provider: Api,
    public toast: ToastController
  ) { }

  ngOnInit() {
    this.carregar();
  }

  carregar() {
    return new Promise(resolve => {
      this.itens = [];

      let dados = {
        numero: this.numero,
      }

      this.api.dadosApi(dados, 'mesas/listarMesa.php').subscribe(data => {
        let result: any = data;
        console.log("Resultado", result.itens, result.itens,length);
        if (result.itens.length == '0') {
          
        } else {
          this.itens = [];
          for (let item of result.itens) {
            this.itens.push(item);

          }
        }

        resolve(true);

      });
    });
  }

  // adicionarMesa() {
  //   if (this.numeroMesa) {
  //     this.api.adicionarMesa(this.numeroMesa).subscribe(
  //       response => {
  //         console.log(response);
  //         this.numeroMesa = null;
  //         this.carregar();
  //       },
  //       error => {
  //         console.error(error);
  //       }
  //     );
  //   } else {
  //     console.log('Informe o número da mesa antes de adicionar.');
  //   }
  // }

  adicionarMesa(){
    return new Promise(resolve =>{
      //declaração de variaveis
      let dados = {
        numero: this.numero,
      };
      let itens:any;

      //comunicação com a API
      this.provider.dadosApi(dados, 'mesas/adicionarMesa.php').subscribe(
        data => {
          itens = data;
          if(itens.ok == true){
            this.router.navigate(['painel']);
            this.msg(itens.msg, "success");
            this.clearFields();
          }else{
            this.msg(itens.msg, "danger");
          }
        }
      )
    });
  }

  //Metodo: Mensagem de retorno
  async msg(msg:string, cor:string){
    const toast = await this.toast.create({
      message: msg,
      duration: 2000,
      color: cor
    });
    toast.present();
  }

  //limpar dados
  clearFields(){
    this.numero  = '';
};
  
  selecionarMesa(mesa: any) {
    this.mesaSelecionada = mesa;
  }

  removerMesa() {
    if (this.mesaSelecionada) {
      const idMesa = this.mesaSelecionada.id; // Substitua 'id' pelo campo correto
      this.api.removerMesa(idMesa).subscribe(
        response => {
          console.log(response);
          this.carregar();
        },
        error => {
          console.error(error);
        }
      );
    } else {
      console.log('Selecione uma mesa antes de remover.');
    }
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }

  navegarAddUsuario() {
    this.router.navigate(['add-usuario']);
  }

  navegarVendas() {
    this.router.navigate(['contabilidade']);
  }

  navegarAddProduto() {
    this.router.navigate(['add-produto']);
  }
}
