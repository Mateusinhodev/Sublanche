import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contabilidade',
  templateUrl: './contabilidade.page.html',
  styleUrls: ['./contabilidade.page.scss'],
})
export class ContabilidadePage implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit() {
  }

  voltar() {
    this.router.navigate(['tabs/painel']);
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }
}
