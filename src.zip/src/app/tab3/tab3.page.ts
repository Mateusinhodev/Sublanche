import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Api } from 'src/services/api';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page implements OnInit{

  itens: any = [];
  limit: number = 10;
  start: number = 0;
  nome: string = '';
  categoria: string = 'Sobremesa';
  count = 0;

  constructor(
    private router: Router,
    private provider: Api,
    private actRouter: ActivatedRoute,
    public toastController: ToastController
  ) {}

  ngOnInit() {
  }

  // Carregamento dinamico na rolagen da lista
  ionViewWillEnter() {
    this.itens = [];
    this.start = 0;
    this.carregar();
  }

  // Carregar os Dados
  carregar() {
    return new Promise(resolve => {
      this.itens = [];

      let dados = {

        nome: this.nome,
        limit: this.limit,
        start: this.start,
        categoria: this.categoria,
      }

      this.provider.dadosApi(dados, 'produtos/listar.php').subscribe(data => {
        let result: any = data;
        console.log("Resultado", result.itens, result.itens,length);
        if (result.itens.length == '0') {
          this.ionViewWillEnter();
        } else {
          this.itens = [];
          for (let item of result.itens) {
            this.itens.push(item);

          }
        }

        resolve(true);

      });
    });
  }

  // Metodo editar
  editar(id_prod: Number, nome: string, descricao: string, preco: string, categoria: string) {
    this.router.navigate(['add-produto', { id_prod: id_prod, nome: nome, descricao: descricao, preco: preco, categoria: categoria}]);
  }

  // // Metodo mostrar 
  // mostrar(id_prod: Number, nome: string, descricao: string, preco: string, categoria: string) {
  //   this.router.navigate(['tab2', { id_prod: id_prod, nome: nome, descricao: descricao, preco: preco, categoria: categoria}]);
  // }

  //Metodo excluir
  excluir(id_prod: Number) {
    return new Promise(resolve => {
      let dados = {
        id_prod: id_prod,

      }
      let result: any;
      this.provider.dadosApi(dados, 'produtos/excluir.php').subscribe(
        data => {
          result = data;
          if (result.ok == true) {
            this.carregar();
            this.mensagem(result.mensagem, 'success');

          } else {
            this.mensagem(result.mensagem, 'danger');
          }
        }
      )
    });
  }

   // Mensagem de retorno
   async mensagem(mensagem: string, cor: string) {
    const toast = await this.toastController.create({
      message: mensagem,
      duration: 2000,
      color: cor
    });
    toast.present();
  }

  //Atualizar visualização dos itens da lista
  handleRefresh(event: any) {
    setTimeout(() => {
      this.ionViewWillEnter();
      event.target.complete();
    }, 500);
  }

  //Carregar os dados por meio do scrool
  loadData(event: any) {

    this.start += this.limit;

    setTimeout(() => {
      this.carregar().then(() => {
        event.target.complete();
      });

    }, 500);


  }

  increment() {
    this.count++;
  }

  decrement() {
    this.count--;
  }

  FazerPedido() {
    this.router.navigate(['pedido']);
  }

  navegarPerfil() {
    this.router.navigate(['perfil']);
  }

}
